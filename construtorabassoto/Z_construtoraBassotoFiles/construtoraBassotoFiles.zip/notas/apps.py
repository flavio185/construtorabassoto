from django.apps import AppConfig


class NotasConfig(AppConfig):
    name = 'notas'
